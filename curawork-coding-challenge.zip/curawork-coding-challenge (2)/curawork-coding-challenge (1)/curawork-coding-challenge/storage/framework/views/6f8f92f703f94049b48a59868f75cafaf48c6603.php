<div class="d-flex align-items-center  mb-2  text-white bg-dark p-1 shadow" style="height: 45px">
  <strong class="ms-1 text-primary">Loading...</strong>
  <div class="spinner-border ms-auto text-primary me-4" role="status" aria-hidden="true"></div>
</div><?php /**PATH /var/www/html/curawork-coding-challenge (2)/curawork-coding-challenge (1)/curawork-coding-challenge/resources/views/components/skeleton.blade.php ENDPATH**/ ?>