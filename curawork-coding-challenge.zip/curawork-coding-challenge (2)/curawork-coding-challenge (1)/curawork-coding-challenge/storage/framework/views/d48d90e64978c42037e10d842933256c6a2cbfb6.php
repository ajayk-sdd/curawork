<div class="p-2 shadow rounded mt-2  text-white bg-dark"><?php if(isset($name)): ?>
      <?php echo e($name); ?>

      <?php endif; ?> - <?php if(isset($email)): ?>
      <?php echo e($email); ?>

      <?php endif; ?></div><?php /**PATH /var/www/html/curawork-coding-challenge (2)/curawork-coding-challenge (1)/curawork-coding-challenge/resources/views/components/connection_in_common.blade.php ENDPATH**/ ?>