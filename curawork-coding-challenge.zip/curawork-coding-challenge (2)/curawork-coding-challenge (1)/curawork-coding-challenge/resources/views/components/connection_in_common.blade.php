<div class="p-2 shadow rounded mt-2  text-white bg-dark">@if (isset($name))
      {{$name}}
      @endif - @if (isset($email))
      {{$email}}
      @endif</div>